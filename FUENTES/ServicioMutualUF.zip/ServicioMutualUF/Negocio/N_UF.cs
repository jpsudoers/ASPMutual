﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccesoDatos;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using Entidades;
using Newtonsoft.Json;

namespace Negocio
{
    public class N_UF
    {
        A_UF datos = new A_UF();
        public string IngresoUF(decimal uf, DateTime fechaUf)
        {   
            var res = datos.setUF(uf, fechaUf);
            return res;
        }
        public string obtenerDatosUF()
        {
           
            WebRequest oRequest = WebRequest.Create("https://api.sbif.cl/api-sbifv3/recursos_api/uf?apikey=f1b7442e5e42fddbbb74024129fc3d25dfc6b9e6&formato=json");
            WebResponse oResponse = oRequest.GetResponse();
            StreamReader sr = new StreamReader(oResponse.GetResponseStream());
            string resultad = sr.ReadToEnd();

            return resultad;
        
        }
        public void consumirAPI()
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            UF datos =  new UF();

            WebRequest request = WebRequest.Create("https://api.sbif.cl/api-sbifv3/recursos_api/uf?apikey=f1b7442e5e42fddbbb74024129fc3d25dfc6b9e6&formato=json");

           

           // var data = Encoding.ASCII.GetBytes(postData);

            request.Method = "GET";
            request.ContentType = "application/json; charset=utf-8";

            WebResponse response = (HttpWebResponse)request.GetResponse();

            var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
            var json = JObject.Parse(responseString);
            var valor = json["UFs"];
            foreach (var a in valor)
            {
                 var valorUF = a["Valor"];
                 var fechaUF = a["Fecha"];
                 datos.Valor = valorUF.ToString();
                 datos.Fecha = fechaUF.ToString();


            }


            var res = IngresoUF(decimal.Parse(datos.Valor), DateTime.Parse(datos.Fecha));
        
        }
    }
}
