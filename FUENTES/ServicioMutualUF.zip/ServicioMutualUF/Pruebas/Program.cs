﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Negocio;

namespace Pruebas
{
    class Program
    {
        static void Main(string[] args)
        {
            N_UF negocio = new N_UF();
            negocio.consumirAPI();
        }
    }
}
