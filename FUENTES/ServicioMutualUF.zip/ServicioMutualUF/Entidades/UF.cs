﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class UF
    {
        public string Valor { get; set; }
        public string Fecha { get; set; }
    }
}
