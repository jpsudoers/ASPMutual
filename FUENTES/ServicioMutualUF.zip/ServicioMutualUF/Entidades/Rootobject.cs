﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Rootobject
    {
        public UFs UFs { get; set; }
    }

    public class UFs
    {
        //public Segment[] segments { get; set; }
        public decimal Valor { get; set; }
        public DateTime Fecha { get; set; }
    }

    public class Segment
    {
        public String Valor { get; set; }
        public DateTime Fecha { get; set; }
    }


}
