﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace AccesoDatos
{
    public class A_UF
    {
        private string _Conn = ConfigurationManager.ConnectionStrings["DBMutual"].ConnectionString;

        public string setUF(decimal uf, DateTime fecha)  
        {
            string res = "0";
            using (SqlConnection conn = new SqlConnection(_Conn))
                try
                {
                    SqlCommand command = new SqlCommand("[SetUF]", conn);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@ValorUF", SqlDbType.Decimal, 10);
                    command.Parameters.Add("@fechaUF", SqlDbType.DateTime);
                    command.Parameters["@ValorUF"].Value = uf;
                    command.Parameters["@fechaUF"].Value = fecha;
                    conn.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        res = reader[0].ToString();
                    }
                    conn.Close();
                    return res;
                }
                catch (Exception e)
                {
                   
                    throw e;

                }

        }
    }
}
