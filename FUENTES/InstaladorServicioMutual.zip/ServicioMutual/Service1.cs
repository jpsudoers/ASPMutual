﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using Negocio;

namespace ServicioMutualUF
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

      protected override void OnStart(string[] args)
        {
            //Timer para el control del tiempo entre llamadas.
            miTimer = new System.Timers.Timer();
            //Intervalo de tiempo entre llamadas.
            miTimer.Interval = 60000;
            //Evento a ejecutar cuando se cumple el tiempo.
            miTimer.Elapsed += new System.Timers.ElapsedEventHandler(miTimer_Elapsed);
            //Habilitar el Timer.
            miTimer.Enabled = true;

            EventLog LogEvento = new EventLog();

            if (!EventLog.SourceExists("UFMutual"))
            {
                EventLog.CreateEventSource("EventoMutual", "UFMutual");
            }

            LogEvento.Source = "UFMutual";
            LogEvento.WriteEntry("Inicio del servicio");


        }

        protected override void OnStop()
        {
            EventLog LogEvento = new EventLog();
            LogEvento.Source = "UFMutual";
            LogEvento.WriteEntry("Detenido");

        }

        public System.Timers.Timer miTimer { get; set; }

        void miTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            EventLog LogEvento = new EventLog();
            N_UF negocio = new N_UF();
            try {
                if (DateTime.Now.ToString("HH:mm") == "00:00")
                {
             
                    LogEvento.Source = "UFMutual";
                    LogEvento.WriteEntry("Obtiene UF");
                    negocio.consumirAPI();
                    LogEvento.Source = "UFMutual";
                    LogEvento.WriteEntry("Guardo Datos");
                }
            }
            catch (Exception) { throw; }
           

        }
    }
}
